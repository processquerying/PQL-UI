package org.pql.core;

/**
 * Artem Polyvyanyy
 */
public enum PQLQuantifier {
	ANY, 
	SOME,
	EACH, 
	ALL;
}