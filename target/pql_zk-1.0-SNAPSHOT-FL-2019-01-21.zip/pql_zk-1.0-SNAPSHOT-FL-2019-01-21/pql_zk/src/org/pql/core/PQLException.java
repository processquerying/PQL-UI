package org.pql.core;

public class PQLException extends Exception {
	
	private static final long serialVersionUID = 7216263497339289883L;
	
	public PQLException() {
		super();
	}

	public PQLException(String arg0) {
		super(arg0);
	}

}
