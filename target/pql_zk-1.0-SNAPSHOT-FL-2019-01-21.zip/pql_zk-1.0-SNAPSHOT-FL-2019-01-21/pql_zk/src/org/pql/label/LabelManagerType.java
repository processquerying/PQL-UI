package org.pql.label;

public enum LabelManagerType {
	LEVENSHTEIN,
	LUCENE,
	THEMIS_VSM
}
